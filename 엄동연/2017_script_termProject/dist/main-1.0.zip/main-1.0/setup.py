from distutils.core import setup

setup(name='main',version='1.0',py_modules=['main'],
      )