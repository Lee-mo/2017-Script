from urllib import request, parse

def getSido():
    global xmlFD, sidoDoc
    try:
        xmlFD = open("유기동물조회+조회조건의+'시도'조건.xml")
    except IOError:
        print("invalid file name or path")
    else:
        try:
            dom = parse(xmlFD)
        except Exception:
            print("loading fail!!!")
        else:
            print("XML Document loading complete")
            sidoDoc = dom
            return dom
    return None

def searchShelter():
    url = 'http://openapi.animal.go.kr/openapi/service/rest/abandonmentPublicSrvc/abandonmentPublic?serviceKey=' \
          'OyfS4qqxnYyHXNdGgHg%2Bem2F%2FLAjaG4C0X2kgqycc%2B2G3%2F0flCjg9GIptnv23C3UXWRH3wjd3EuE31%2FGSX71ZA%3D%3D'
    print("보호소 검색")
    sido=input("시도 조건(ex. 서울특별시, 부산광역시, 경기도, 충청남도): ")
    sigungu=input("시군구 조건(ex. 강남구): ")
    request1 = request.Request("")
    request1.get_method = lambda: 'GET'
    response_body = request.urlopen(request1).read()
    print(response_body)