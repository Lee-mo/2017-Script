from urllib import request
from xml.etree import ElementTree

url_home = 'http://openapi.animal.go.kr/openapi/service/rest/abandonmentPublicSrvc/'
serviceKey = 'serviceKey=OyfS4qqxnYyHXNdGgHg%2Bem2F%2FLAjaG4C0X2kgqycc%2B2G3%2F0flCjg9GIptnv23C3UXWRH3wjd3EuE31%2FGSX71ZA%3D%3D'
url_sido = url_home + "sido?" + serviceKey

code_dog = "417000"
code_cat = "000116"
code_other = "000117"

def searchShelter():
    global sido_code, sigungu_code

    print("==========유기동물 보호소 검색==========")

    # 시/도 코드 찾기
    sido_name = input("시/도를 입력하세요: ")
    sido_code = getRegionCode(url_sido, sido_name)

    # 시/군/구 코드 찾기
    sigungu_name = input("시/군/구를 입력하세요: ")
    url_sigungu = url_home+'sigungu?'+serviceKey+'&upr_cd=' + sido_code
    sigungu_code = getRegionCode(url_sigungu, sigungu_name)

    #보호소 찾기
    url_shelter = url_home + 'shelter?' + serviceKey + '&upr_cd=' + sido_code + '&org_cd=' + sigungu_code
        #보호소 출력
    print('보호소 목록: ')
    printItem(url_shelter, "careNm")
    print("========================================")

def searchAnimal():
    print("==========유기동물 검색==========")
    animal_kind = input("동물 종류(개, 고양이, 기타, 모두): ")
    if animal_kind == "개":
        animal_code = code_dog
        dog_kind = input("품종(품종이름, 모두): ")
        if dog_kind == "모두":
            code_dogKind = ""
        else:
            url_dogKind = url_home + "kind?" + serviceKey + "&up_kind_cd=" + code_dog
            code_dogKind = getDogKindCode(url_dogKind,dog_kind)

    elif animal_kind == "고양이":
        animal_code = code_cat
        code_dogKind = ""
    elif animal_kind == "기타":
        animal_code = code_other
        code_dogKind = ""
    elif animal_kind == "모두":
        animal_code = ""
        code_dogKind = ""

    date_start = input("유기날짜 (검색 시작일 YYYYMMDD): ")
    date_end = input("유기날짜 (검색 종료일 YYYYMMDD): ")
    item_num = input("보고 싶은 동물 수: ")
    sido_name = input("시/도 조건: ")
    sigungu_name = input("시/군/구 조건: ")
    sido_code = getRegionCode(url_sido, sido_name)
    url_sigungu = url_home + 'sigungu?' + serviceKey + '&upr_cd=' + sido_code
    sigungu_code = getRegionCode(url_sigungu, sigungu_name)

    url_animal = url_home + "abandonmentPublic?" + serviceKey + "&bgnde=" + date_start + "&endde=" + date_end + "&upkind=" + animal_code + "&kind=" + code_dogKind + "&numOfRows=" + item_num
    printAnimal(url_animal)
    print("=================================")

def getRegionCode(url, search_name):
    response = request.urlopen(url).read()
    tree = ElementTree.fromstring(response)
    itemElements = tree.getiterator("item")
    for item in itemElements:
        name = item.find('orgdownNm')
        name = name.text
        if name == search_name:
            result = item.find("orgCd")
            return result.text

def getDogKindCode(url, search_name):
    response =  request.urlopen(url).read()
    tree = ElementTree.fromstring(response)
    itemElements = tree.getiterator("item")
    for item in itemElements:
        name = item.find('KNm')
        name = name.text
        if name == search_name:
            result = item.find("kindCd")
            return result.text

def printItem(url, item_name):
    response = request.urlopen(url).read()
    tree = ElementTree.fromstring(response)
    itemElements = tree.getiterator("item")
    for item in itemElements:
        name = item.find(item_name)
        print(name.text)

def printAnimal(url):
    response = request.urlopen(url).read()
    tree = ElementTree.fromstring(response)

    itemElements = tree.getiterator("header")
    for item in itemElements:
        name = item.find("resultCode")
    if name.text == "00":
        print("============================================================")
        print("결과 없음.")
        print("============================================================")

    else:
        itemElements = tree.getiterator("item")

        for item in itemElements:
            print("============================================================")
            print("-----동물정보-----")
            name = item.find("processState")
            if name != None:print("상태: ", name.text)

            name = item.find("kindCd")
            if name != None:print("품종: ", name.text)

            name = item.find("age")
            if name != None:print("나이: ", name.text)

            name = item.find("sexCd")
            if name != None:print("성별: ", name.text)

            name = item.find("colorCd")
            if name != None:print("색상: ", name.text)

            name = item.find("neuterYn")
            if name != None:print("중성화 여부: ", name.text)

            name = item.find("specialMark")
            if name != None:print("특징: ", name.text)

            name = item.find("weight")
            if name != None:print("체중: ", name.text)

            name = item.find("happenPlace")
            if name != None: print("발견장소: ", name.text)

            print("-----보호 정보-----")
            name = item.find("careNm")
            if name != None: print("보호소 이름: ", name.text)

            name = item.find("careAddr")
            if name != None:print("보호 주소: ", name.text)

            name = item.find("careTel")
            if name != None:print("보호소 전화번호: ", name.text)

            name = item.find("chargeNm")
            if name!= None: print("담당자: ", name.text)

            name = item.find("officetel")
            if name != None:print("담당자 연락처: ", name.text)

            name = item.find("happenDt")
            if name != None:print("접수일: ", name.text)

            name = item.find("orgNm")
            if name != None:print("관할기관: ", name.text)

            name = item.find("noticeNo")
            if name != None:print("공고번호: ", name.text)

            name = item.find("desertionNo")
            if name != None:print("유기번호: ", name.text)

            print("============================================================")