from tkinter import *

window_name = "사지 마세요, 입양하세요! (Don't Buy Do Adopt!)"
window_main = Tk(className=window_name)

window_main.geometry("1080x720+400+100")



window_main.mainloop()