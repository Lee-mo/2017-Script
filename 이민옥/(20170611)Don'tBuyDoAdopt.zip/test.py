from tkinter import *

window = Tk(className= "test")
photo = PhotoImage(file="귓속말.gif")
imageLabel = Label(window, image=photo)
imageLabel.pack()


window.mainloop()