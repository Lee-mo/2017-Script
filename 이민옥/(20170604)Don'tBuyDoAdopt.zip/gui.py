from tkinter import *
from tkinter import font

def draw(window):
    menu_font = font.Font(window, size=20)
    name_k = Label(window, text="사지마세요, 입양하세요!", font='helvetica 30')
    name_e = Label(window, text="Don't Buy, Do Adopt!", font='helvetica 15')

    menu_shelter = Button(window, text = "유기동물 보호소 검색", font=menu_font)
    menu_animal = Button(window, text = "유기동물 검색", font=menu_font)

    name_k.place(x=300, y=0)
    name_e.place(x=400, y=50)
    menu_shelter.place(x=300, y=100)
    menu_animal.place(x=300, y=150)

