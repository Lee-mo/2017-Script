from tkinter import *
from tkinter import font
from search import *
from PIL import Image, ImageTk
from io import BytesIO

TITLE, SSLT, SANM = 1, 2, 3
loopFlag = True
photo = None
menu = TITLE

window_name = "사지 마세요, 입양하세요! (Don't Buy Do Adopt!)"
window_main = Tk(className=window_name)
window_main.geometry("1080x720+400+100")

def draw_title():
    global photo
    photo = PhotoImage(file="귓속말.gif")

    menu_font = font.Font(window_main, size=20)
    name_k = Label(window_main, text="사지마세요, 입양하세요!", font='helvetica 30')
    name_e = Label(window_main, text="Don't Buy, Do Adopt!", font='helvetica 15')
    button_shelter = Button(window_main, text="보호소 검색", font=menu_font, bg='skyblue')
    button_animal = Button(window_main, text="유기동물 검색", font=menu_font, bg='skyblue')
    imageLabel = Label(window_main, image=photo)

    name_k.pack()
    name_e.pack()
    button_shelter.pack()
    button_animal.pack()
    imageLabel.pack()

    name_k.place(x=330, y=50)
    name_e.place(x=430, y=100)
    button_shelter.place(x=300, y=550)
    button_animal.place(x=560, y=550)
    imageLabel.place(x=250, y=150)

def draw_shelter():
    title_font = font.Font(window_main, size=20, weight='bold')
    main_text = Label(window_main, font=title_font, text="유기동물 보호소 검색", command=title_shelter_action)
    main_text.pack()
    main_text.place(x = 10)

def title_shelter_action():
    global menu
    menu = SSLT
    print(menu)
def main():
    global menu
    if menu == TITLE:
        draw_title()
    elif menu == SSLT:
        draw_shelter()
    window_main.mainloop()

while(True):
    main()

