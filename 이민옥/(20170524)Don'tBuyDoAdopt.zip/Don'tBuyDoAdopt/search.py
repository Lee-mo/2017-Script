from urllib import request
from xml.etree import ElementTree

url_home = 'http://openapi.animal.go.kr/openapi/service/rest/abandonmentPublicSrvc/'
serviceKey = 'serviceKey=OyfS4qqxnYyHXNdGgHg%2Bem2F%2FLAjaG4C0X2kgqycc%2B2G3%2F0flCjg9GIptnv23C3UXWRH3wjd3EuE31%2FGSX71ZA%3D%3D'

def searchShelter():
    global sido_code, sigungu_code

    print("==========보호소 검색==========")

    # 시/도 코드 찾기
    sido_name = input("시/도를 입력하세요: ")
    url_sido = url_home + "sido?" + serviceKey
    response = request.urlopen(url_sido).read()
    sido_code = getRegionCode(response, sido_name)

    # 시/군/구 코드 찾기
    sigungu_name = input("시/군/구를 입력하세요: ")
    url_sigungu = url_home+'sigungu?'+serviceKey+'&upr_cd=' + sido_code
    response = request.urlopen(url_sigungu).read()
    sigungu_code = getRegionCode(response, sigungu_name)

    #보호소 찾기
    url_shelter = url_home + 'shelter?' + serviceKey + '&upr_cd=' + sido_code + '&org_cd=' + sigungu_code
    response = request.urlopen(url_shelter).read()

    #보호소 출력
    print('보호소 목록: ')
    printItem(response, "careNm")

def getRegionCode(response, search_name):
    tree = ElementTree.fromstring(response)
    itemElements = tree.getiterator("item")
    for item in itemElements:
        name = item.find('orgdownNm')
        name = name.text
        if name == search_name:
            result = item.find("orgCd")
            return result.text

def printItem(response, item_name):
    tree = ElementTree.fromstring(response)
    itemElements = tree.getiterator("item")
    for item in itemElements:
        name = item.find(item_name)
        print(name.text)