from urllib import request
import xml.parsers.expat

def print10():

    response_body = request.urlopen('http://openapi.animal.go.kr/openapi/service/rest/abandonmentPublicSrvc/abandonmentPublic?'
                                    'serviceKey=OyfS4qqxnYyHXNdGgHg%2Bem2F%2FLAjaG4C0X2kgqycc%2B2G3%2F0flCjg9GIptnv23C3UXWRH3wjd3EuE31%2FGSX71ZA%3D%3D&'
                                    'bgnde=20140601&endde=20170521&upkind=417000&numOfRows=1&pageSize=1').read()
    def start_element(name, attrs):
        print('Start elem: ',name,attrs)
    def char_data(data):
        print('Char data: ',repr(data))

    pa = xml.parsers.expat.ParserCreate()
    pa.StartElementHandler = start_element
    pa.CharacterDataHandler = char_data
    pa.Parse(response_body)


def searchShelter():
    url = 'http://openapi.animal.go.kr/openapi/service/rest/abandonmentPublicSrvc/abandonmentPublic?serviceKey=' \
          'OyfS4qqxnYyHXNdGgHg%2Bem2F%2FLAjaG4C0X2kgqycc%2B2G3%2F0flCjg9GIptnv23C3UXWRH3wjd3EuE31%2FGSX71ZA%3D%3D'
    print("보호소 검색")
    sido=input("시도 조건(ex. 서울특별시, 부산광역시, 경기도, 충청남도): ")
    sigungu=input("시군구 조건(ex. 강남구): ")
    request1 = request.Request("")
    request1.get_method = lambda: 'GET'
    response_body = request.urlopen(request1).read()
    print(response_body)

def checkDocument():
    global animalsDoc
    if animalsDoc == None:
        print('에러: animalsDoc 비어있음.')
        return False
    else: return True